﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using MyAspNetCoreApp.Filters;
using StudentApplication.Models;
using System.Reflection;


namespace StudentApplication.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        [OutputCache(Duration = 60)]
        [LoggingFilter]

        [ServiceFilter(typeof(CustomExceptionFilter))]
        public ActionResult Index()
        {
            var students = new List<Student>
        {
            new Student { StudentId = 1, StudentName = "John", Age = 18 },
            new Student { StudentId = 2, StudentName = "Steve", Age = 21 },
            new Student { StudentId = 3, StudentName = "Bill", Age = 25 }
        };

            ViewBag.UserName = "Vishal Waghmode";

            ViewData["count"] = 10;

            TempData["Name"] = "Hello, vishallll.....";

            List<String> names = new List<String> {"vishal" , "Amol" , "Sayali" };
            ViewData["NameList"] = names;
            ViewBag.NameList = names;

            //var student = new Student { StudentId = 1, StudentName = "Alice", Age = 20 };
            //ViewBag.Student = student;
            return View(students);


            //return View(students);
        }

        [ActionName("getdata")]
        public JsonResult GetStudent()
        {
            var std = new List<string> { "vishal", "Amol", "Sayali" };
            return new JsonResult(std);

        }
        public RedirectResult RedirectToGoogle()
        {
            return new RedirectResult("https://www.google.com");
        }

        public ContentResult DisplayMessage()
        {
            return Content("Hello, World!", "text/plain");
        }
        [Route("ViewPage")]
        public ActionResult ViewPage()
        {
            return RedirectToAction("Index", "Student");
        }
    }

}
