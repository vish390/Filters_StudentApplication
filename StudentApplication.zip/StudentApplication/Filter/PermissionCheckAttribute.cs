﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace StudentApplication.Filter
{
    public class PermissionCheckAttribute : ActionFilterAttribute
    {
        public string Permission { get; set; }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            // Accessing user claims
            var user = context.HttpContext.User;
            if (!user.HasClaim(c => c.Type == "Permission" && c.Value == Permission))
            {
                // Redirecting to AccessDenied action if permission is not found
                context.Result = new RedirectToRouteResult(
                    new RouteValueDictionary(new { controller = "Home", action = "AccessDenied" })
                );
            }
            base.OnActionExecuting(context);
        }
    
}
}
