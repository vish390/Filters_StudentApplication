﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

public class CustomExceptionFilter : IExceptionFilter
{
    private readonly ILogger<CustomExceptionFilter> _logger;

    public CustomExceptionFilter(ILogger<CustomExceptionFilter> logger)
    {
        _logger = logger;
    }

    public void OnException(ExceptionContext context)
    {
        // Log the exception details
        _logger.LogError(context.Exception, "An unhandled exception occurred.");

        // Set the result to a standardized error response
        context.Result = new JsonResult(new
        {
            Message = "An unexpected error occurred. Please try again later.",
            Details = context.Exception.Message
        })
        {
            StatusCode = 500
        };

        // Mark the exception as handled
        context.ExceptionHandled = true;
    }
}
