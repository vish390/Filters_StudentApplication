﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;

namespace MyAspNetCoreApp.Filters
{
    public class LoggingFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            Console.WriteLine($"Action {context.ActionDescriptor.DisplayName} is executing at {DateTime.Now}");
            base.OnActionExecuting(context);
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine($"Action {context.ActionDescriptor.DisplayName} has executed at {DateTime.Now}");
            base.OnActionExecuted(context);
        }
    }
}
